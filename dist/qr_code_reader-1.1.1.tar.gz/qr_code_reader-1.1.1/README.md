# QR Code Reader

A simple Python package for reading QR codes from input and managing a queue.

## Installation

```bash
pip install qr_code_reader
# QR Code Reader

A simple Python package for reading QR codes from input and managing a queue.

## Installation

```bash
pip install qr_code_reader

