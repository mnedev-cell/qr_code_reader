from .qr_code_reader import QRCodeReader

