from .QrCodeReader import QRCodeReader



